<?php
	try{
		$conexao = new PDO('mysql:host=mysql.hostinger.com.br;dbname=u946217394_feed', 'u946217394_admin', 'ultra1234');
		$conexao ->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	}catch(PDOException $e){
		echo 'ERROR: ' . $e->getMessage();
	}
?>