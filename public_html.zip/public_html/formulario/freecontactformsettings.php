<?php

$email_to = "danillovilanova0@gmail.com"; // your email address
$email_subject = "Enviar"; // email subject line
$thankyou = "thankyou.htm"; // thank you page

// if you update the question on the form -
// you need to update the questions answer below
$antispam_answer = "25";

?>